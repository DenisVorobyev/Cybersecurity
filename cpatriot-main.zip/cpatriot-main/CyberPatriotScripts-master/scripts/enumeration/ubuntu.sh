# Ask for password for sudo
printf "Password: "
read -s userpassword

# Make a folder for output
mkdir ~/LDist

# Run linenum
echo $userpassword | ./LinEnum.sh -t -s -r $HOSTNAME

cd ~/LDist
# Copy files
cp /etc/hosts hosts
ls -al /etc/rc.local > rc.local
cp /etc/passwd passwd
cp /etc/group group
echo $userpassword | sudo -S cp /etc/shadow shadow
echo $userpassword | sudo -S chmod 777 shadow

# Check last logins
last > logins
echo "# Lastlog" >> logins
lastlog >> logins

# Services
netstat -tulnp > netstat
(echo $userpassword | sudo -S service --status-all) > services
dpkg -l > packages
(echo $userpassword | sudo -S ps aux) > processes
