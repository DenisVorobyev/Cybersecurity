# Modules for Windows
## Start Updates
Install WSUS and begin downloading
Install updates during pizza time
## Enumeration Script
Find script in /scripts/enumeration/windows.bat  
Sourced from [winprivesc](https://github.com/joshruppe/winprivesc)
## Unauthorized Files
In progress
## Auditing/Firewall
Done
```
enable-firewall.bat password-audit.bat
```
## Disable/Enable Services
Disable weak services (Remote Desktop, etc.)
## Registry Keys
Lots of them, split into different sections
## Browser Settings
Extra security for IE and Chrome
## Misc
Registry key edits
