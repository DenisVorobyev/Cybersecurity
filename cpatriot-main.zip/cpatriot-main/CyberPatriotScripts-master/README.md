# CyberPatriot
## About:
Scripts for L Distribution, a Poolesville HS based CyberPatriot team
## Scripts:
Linux Enumeration
Windows Enumeration
Windows Browser Security (IE)
Windows Firewall/Port Blocking
Windows Password/Auditing
Windows Services Disable
Windows Updates
Windows Misc.
