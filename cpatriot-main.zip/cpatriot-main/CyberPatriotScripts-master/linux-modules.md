## Enumeration
- https://github.com/rebootuser/LinEnum
- /etc/shadow permissions
- /etc/hosts
- /etc/rc.local, other autostart stuff
- /etc/passwd - uid 0, strange groups
- /etc/group
- previous logins
- check listening (netstat -tulnp)
- list services
- list all packages
- sus packages - netcat, "hacking tools"
- common vulns - kernel, bash, readme services
- installed package diff
- ps -ef at start, diff, top sort by cpu, ram
- crontab (all users and root)
- extract all histories
- capabilities (getcap -r /)

## CCS Extension
- read readme
- list forensics
- push all enum info to server

## Logs
- /var/log/messages
- /var/log/boot
- /var/log/debug
- /var/log/auth.log
- /var/log/daemon.log
- /var/log/kern.log
- push to server, develop regexes for typical issues

## Users
- root disabled
- groups
- guest user
- add/remove
- diff home dirs
- search for media
- sudoers

## Services
- /etc/resolv.conf - change to 8.8.8.8
- ssh - disable root, ciphers, password requirement, check /etc/ssh for extra files
- ftp - enforce password stuff, anonymous logon

## Passwords
- check passwords
- password expiration
- password length


## Updates
- clean up dkpg database
- /etc/apt/sources.list CHECK BEFORE UPDATES
- download in background
- enable autoupdates

## Firewall
- ss -ln
- sudo ufw enable
- sysctl -n net.ipv4.tcp_syncookies

## ClamTK
- scan

## AppArmor/SELinux
- probably manual
