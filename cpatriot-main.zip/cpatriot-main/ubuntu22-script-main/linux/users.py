import os

print("""
YOU ARE RUNNING USERS.PY  MAKE SURE THE FILES
* authorized_users.txt
* authorized_sudoers.txt
are there.
""")
cont = input("Continue? (y/n)")
if cont != "y":
    print("\n\n\nBYE! (DID NOT DO ANYTHING)")
    exit()

######## USERS ########

users = os.popen(
    "awk -F: '($3>=1000)&&($1!=\"nobody\"){print $1}' /etc/passwd").read().split('\n')
users = list(filter(None, users))  # remove empty strings
print(users)

cont = input("Continue? (y/n)")
if cont != "y":
    print("\n\n\nBYE! (CAUTION DID NOT DO USER STUFF)")
    exit()

with open('./authorized_users.txt', 'r') as file:
    allowed_users = file.read()

    for user in users:  # delete unauthorized users
        if user not in allowed_users:
            os.system('sudo userdel -r {}'.format(user))
            print('Deleted {}'.format(user))

with open('./authorized_users.txt', 'r') as file:
    for line in file:  # add users that need to be added
        user = line.strip('\n').strip()

        if user not in users:  # check if user isn't already there
            print('Added {}'.format(user))
            os.system('sudo useradd {}'.format(user))

######## SUDOERS ########

allowed_sudoers = []

# read this file to know what users that are allowed
with open("authorized_sudoers.txt") as file:
    for line in file:
        line = line.strip('\n').strip()
        allowed_sudoers.append(line)

# Adding sudoers
for user in allowed_sudoers:  # add users in allowed_users if they are not already there
    os.system('sudo adduser {} sudo || true'.format(user))

# Deleting sudoers
raw_sudoers = os.popen("grep -Po '^sudo.+:\K.*$' /etc/group").read()

sudoers = raw_sudoers.strip('\n').split(',')  # current sudoers

print(sudoers)
cont = input("Continue? (y/n)")
if cont != "y":
    print("\n\n\nBYE! (CAUTION DID NOT DELETE SUDOERS BUT ADDED)")
    exit()

for user in sudoers:
    if user not in allowed_sudoers:
        os.system('sudo deluser {} sudo'.format(user))
