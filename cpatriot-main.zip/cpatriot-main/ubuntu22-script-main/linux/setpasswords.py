import os
print("""
YOU ARE RUNNING SETPASSWORDS.PY  MAKE SURE
* users.py was successfully run
""")
cont = input("Continue? (y/n)")
if cont != "y":
    print("\n\n\nBYE! (DID NOT DO ANYTHING)")
    exit()

######## PASSWORDS ########


new_passwords = [
    "Gre@t1TrueBean",
    "Gre@t1TrueWort",
    "Gre@t1TrueTaro",
    "Gre@t1TrueKale",
    "Gre@t1TrueLeek",
    "Gre@t1TrueOkra",
    "Gre@t1TrueBeet",
    "Gre@t1TrueOnion",
    "Gre@t1TrueChive",
    "Gre@t1TrueSwede",
    "Gre@t1TrueChard",
    "Gre@t1TrueChoko",
    "Gre@t1TrueMelon",
    "Gre@t1TrueMango",
    "Gre@t1TrueLemon",
    "Gre@t1TruePapay",
    "Gre@t1TruePeach",
    "Gre@t1TrueBerry",
    "Gre@t1TrueLime",
    "Gre@t1TruePear",
    "Gre@t1TrueSloe",
    "Gre@t1TrueBear",
    "Gre@t1TrueKiwi",
    "Gre@t1TrueDate",
    "Gre@t1TruePlum",
    "Gre@t1TrueMake",
    "Gre@t1TrueCone",
    "Gre@t1TrueCarpic",
    "Gre@t1TruePapaya",
    "Gre@t1TrueCherry",
]

users = os.popen(
    "awk -F: '($3>=1000)&&($1!=\"nobody\"){print $1}' /etc/passwd").read().split('\n')
users = list(filter(None, users))  # remove empty strings
print(users)


cont = input("Continue? Make sure users are created (y/n)")
if cont != "y":
    print("\n\n\nBYE!")
    exit()

passwords = []  # stores username and passwords as tuples in list

for num, password in enumerate(new_passwords):
    if num > len(users) - 1:
        break

    os.system("sudo echo -e \"{}\n{}\" | sudo passwd {}".format(password,
              password, users[num]))  # CRUCIAL LINE
    passwords.append((users[num], password))

print(passwords)

with open("USER_PASSWORDS.txt", "w") as outFile:
    outFile.write(str(passwords))

print("\n\nBye!")
