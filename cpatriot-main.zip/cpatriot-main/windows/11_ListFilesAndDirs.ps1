﻿#Dirs: desktop, documents, downloads, favorites, music, pictures, saved games, videos
#get a list of users in the users directory of the C drive, then recurse into each of the above directories for each user and list out files
$users = @()
$dirs = @("Desktop", "Documents", "Downloads", "Favorites", "Music", "Pictures", "Saved Games", "Videos")
$(Get-ChildItem -Path "C:\Users\" -Name) | foreach {
    $users += $_
}
$users | foreach {
    $user = $_
    $dirs | foreach {
        $dir = $_
        $temp = "C:\Users\" + [string]$user + "\" + [string]$dir
        Get-ChildItem -Path $temp -Recurse
    }
}