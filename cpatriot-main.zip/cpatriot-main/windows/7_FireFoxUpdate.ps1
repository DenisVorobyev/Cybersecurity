$ff = Invoke-WebRequest  "https://product-details.mozilla.org/1.0/firefox_versions.json" | ConvertFrom-Json
$name = "firefox.exe"
$searchPath = Get-ChildItem -Path c:\ -Recurse $name | Select-Object -Property FullName | foreach{$_.FullName}
if (!$searchPath) {
    Write-Host("$Name Does not exist..Script ending")
}else {
    if ($searchPath -is [system.array]) {
        $path = $searchPath[1]
    }else {
        $path = $searchPath
    }
    $cV = (Get-Item $path).VersionInfo
    $FileVersion = ("{0}.{1}.{2}" -f $cV.FileMajorPart, 
        $cV.FileMinorPart, 
        $cV.FileBuildPart)
    if ([version]$FileVersion -lt [version]$($ff.psobject.properties["LATEST_FIREFOX_VERSION"].Value)){
        $workdir = "c:\installer\"
        If (Test-Path -Path $workdir -PathType Container){ 
            Write-Host "$workdir already exists" -ForegroundColor Red}
        ELSE{ 
            New-Item -Path $workdir  -ItemType directory
        }
       $source = "https://download.mozilla.org/?product=firefox-latest&os=win64&lang=en-US"
       $destination = "$workdir\" + $name
        if (Get-Command 'Invoke-Webrequest')
        {
             Invoke-WebRequest $source -OutFile $destination
        }
        else
        {
            $WebClient = New-Object System.Net.WebClient
            $webclient.DownloadFile($source, $destination)
        }
        Start-Process -FilePath $destination -ArgumentList "/S"
        Start-Sleep -s 35
        $new_version = (Get-Item $path).VersionInfo
        $NewFileVersion = ("{0}.{1}.{2}" -f $new_version.FileMajorPart, 
        $new_version.FileMinorPart, 
        $new_version.FileBuildPart)
        Write-Host "Firefox is now version: $NewFileVersion"
    }else {
        Write-Host "Firefox is already the latest version: $FileVersion"
    }
}