﻿# Remove-Item -path C:\Users\ -include *.mp3 -recurse
# Remove-Item -path C:\Users\ -include *.mp4 -recurse

Get-ChildItem *.exe
Get-ChildItem *.mp3
Get-ChildItem *.jpg
Get-ChildItem *.png
Get-ChildItem *.jpeg
Get-ChildItem *.mp4
Get-ChildItem *.mp4a
