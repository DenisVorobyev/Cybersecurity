# Linux Checklist

Go to terminal and type in

```bash
sudo apt-get install git
git clone "https://github.com/sswadkar/cypat.git"
cd cypat\linux
```

Copy paste the readme information into the readme.txt

```bash
gedit readme.txt
chmod +x ubuntuscript.sh
```

## Forensics Questions

1. This should be the first thing you do because running scripts will delete things like mp3 files and then you won’t know the path of them

- strace
  - strace calendar -e execve -f
- Finding a file called <name>
  - sudo find / -type f -name "<name>\*"
- Unzipping a file
  - sudo apt-get install p7zip-full
  - 7z x <directory>
- Finding listening ports
  - sudo lsof -i -P -n | grep LISTEN
  - sshd 85379 root 3u IPv4 0xffff80000039e000 0t0 TCP 10.86.128.138:22 (LISTEN)
    - sshd is the name of the application.
    - 10.86.128.138 is the IP address to which sshd application bind to (LISTEN)
    - 22 is the TCP port that is being used (LISTEN)
    - 85379 is the process ID of the sshd process
- Specific port
  - sudo lsof -i:<PORT_NUMBER>

## Running the script

- Go to Software & Updates > Updates > Configure the last option for a system update
- `./ubuntuscript.sh`
- Make sure to have the readme up while answering the questions so you disable the right services

## When to disable things

- Samba
  - Used for client-serve networking for file and printer sharing
  - Unless it specifically asks for a Sever Message Block (SMB) Protocol you should disable it
- FTP
  - File Transfer Protocol Service
  - Unless it tells you to keep it disable it
    - FTP lacks privacy and integrity and makes it fairly easy for a hacker to gain access and capture or modify your data while it's in transit.
- SSH
  - Unless it tells you to **DO NOT** disable SSH
  - If Openssh is a critical service then don't disable it
- Telnet
  - Disable if SSH is enabled
- Mailing Services and Printing
  - If you don't want unauthorized polling tools or stuff like that disable mailing services
- Web Server
  - Disable Apache2 unless it tells you not to (you can always go back and turn it back on with

```bash
sudo apt-get install apache2
	sudo ufw allow http
	sudo ufw allow https
```

- DNS
  - Unless it telsl you not to, disable it
  - You can always renable with

```bash
sudo apt-get install bind9
	sudo ufw allow domain
```

- Media Files
  - It'll tell you in the readme whether or not you should disable media files
- IPv6
  - If the readme doesn't mention IPv6 and doesn't use it, disable it

## Deleting unauthorized programs

- Go to Applications
- Look for hacking apps, games, etc. anything that isn't allowed

## Update Linux Kernel

`update-manager –d`
Force and update checker and click upgrade if you have an option to.

- After Notifying me of a new Ubuntu version: For any new version you should get a dialog box to update

## Before submitting score

```bash
sudo chmod -R 444 /var/log
sudo chmod 440 /etc/passwd
sudo chmod 440 /etc/shadow
sudo chmod 440 /etc/group
sudo chmod -R 444 /etc/ssh
```

To lock all files.
